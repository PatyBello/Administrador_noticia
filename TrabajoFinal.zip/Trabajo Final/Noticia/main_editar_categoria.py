#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import controller
from PySide import QtGui, QtCore
from editar_categoria import Ui_Editar_categoria


class main(QtGui.QDialog):

    def __init__(self, nombre = None):
        super(main, self).__init__()
        self.ui = Ui_Editar_categoria()
        self.ui.setupUi(self)
        self.show()
        self.nombre = nombre
        # nuestra el valor del nombre a editar
        self.ui.lineEdit.setText(nombre)
        # acciones a botones
        self.ui.Editar.clicked.connect(self.Edit)
        self.ui.Salir.clicked.connect(self.cancel)

    def Edit(self, id_categoria = None, categoria = None , nuevo = None):
         id_categoria = controller.id_categoria(self.nombre)
         #guarda el id de la categoria a editar
         id_cate = id_categoria["id_categoria"]
         nuevo_nombre = self.ui.lineEdit.text()
         # verifica que se ingrese un dato
         if nuevo_nombre:
             existe = controller.nombre_categoria(str(nuevo_nombre))
             # si no existe el dato lo agrega 
             if existe:
                 self.errorMessageDialog = QtGui.QErrorMessage(self)
                 self.errorMessageDialog.showMessage("la categoria ya existe")
             else:
                 resultado = controller.editar_categoria(id_cate,nuevo_nombre)
                 if resultado:
                     self.errorMessageDialog = QtGui.QErrorMessage(self)
                     self.errorMessageDialog.showMessage("El registro a sido actualizado")
                 else:
                     self.errorMessageDialog = QtGui.QErrorMessage(self)
                     self.errorMessageDialog.showMessage("A sucedido un problema no se a podido actualizar el registro")
         else:
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage("Debe ingresar un nombre")
             
    def cancel(self):
        self.reject()
         
