#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from PySide import QtGui, QtCore
import controller_n
from editar_noticia import Ui_Editar_noticia


class main(QtGui.QDialog):

    def __init__(self , nombre = None):
        super(main, self).__init__()
        self.ui = Ui_Editar_noticia()
        self.ui.setupUi(self)
        self.cargar_categoria()
        self.show()
        self.set_listeners()
   
        noticia = controller_n.obtener_noticia_nombre(nombre)
        for note in noticia:
             id_noticia = noticia[7]
             publicada = noticia[3]
             #titulo , categoria, autor , fecha   
             self.ui.lineEdit_5.setText(noticia[0])
             self.ui.lineEdit.setText(noticia[6])
             self.ui.lineEdit_2.setText(noticia[5])
             self.ui.lineEdit_3.setText(noticia[1])
             self.ui.lineEdit_4.setText(noticia[3])
             self.ui.textEdit.setText(noticia[4])
             self.ui.textEdit_2.setText(noticia[2])

        self.id_note = id_noticia
        self.publica = publicada

    def cargar_categoria(self):
        categoria = controller_n.obtener_categoria()
        for cate in categoria:
            self.ui.comboBox.addItem(cate["nombre"], cate["id_categoria"])


    def radio_boto(self):
        cont = 0
        if self.ui.radioButton.isChecked() == True:
            cont = cont +1
        if self.ui.radioButton_2.isChecked() == True:
            cont = cont +1
            
        if cont == 1:
            if self.ui.radioButton.isChecked() == True:
                aux = 'S'
                categoria =self.ui.comboBox.itemData(self.ui.comboBox.currentIndex())
            if self.ui.radioButton_2.isChecked() == True:
                aux = 'N'
                categoria =self.ui.comboBox.itemData(self.ui.comboBox.currentIndex())
           
            return aux , categoria
        
    def agregar(self , crear_noticia = None):
         # toma los valores ingresados para agregarlos a la base de datos
         titulo = self.ui.lineEdit_5.text()
         autor = self.ui.lineEdit_2.text()
         year = self.ui.dateEdit.date().year()
         month = self.ui.dateEdit.date().month()
         day = self.ui.dateEdit.date().day()
         resumen = self.ui.textEdit.toPlainText()
         texto = self.ui.textEdit_2.toPlainText()
         aux = self.radio_boto()
         fecha = day , month , year
         fecha_in =str('{:0>2}'.format(fecha[0]))+ "-" + str('{:0>2}'.format(fecha[1])) + "-" + str(fecha[2])
         # si se a seleccionado alguna opcion de publicada se agrega si no quiere decir que
         # no se tomara el valor ya existente
         if aux:
             editar = controller_n.editar_noticia(titulo, fecha_in, texto, resumen, aux[0], autor, self.id_note , aux[1])
             if editar:
                 self.errorMessageDialog = QtGui.QErrorMessage(self)
                 self.errorMessageDialog.showMessage(" Se a editado correctamente")
             else:
                 self.errorMessageDialog = QtGui.QErrorMessage(self)
                 self.errorMessageDialog.showMessage(" A ocurrido un error no se a podido editar")
         else:
             categoria =self.ui.comboBox.itemData(self.ui.comboBox.currentIndex())
             editar = controller_n.editar_noticia(titulo, fecha_in, texto, resumen,str(self.publica), autor, self.id_note , str(categoria))
             if editar:
                 self.errorMessageDialog = QtGui.QErrorMessage(self)
                 self.errorMessageDialog.showMessage(" Se a editado correctamente")
             else:
                 self.errorMessageDialog = QtGui.QErrorMessage(self)
                 self.errorMessageDialog.showMessage(" A ocurrido un error no se a podido editar")
         

    def set_listeners(self):
        self.ui.Editar.clicked.connect(self.agregar)
        self.ui.Salir.clicked.connect(self.cancel)
    
    def cancel(self):
        self.reject()  

        
