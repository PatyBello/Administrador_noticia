# -*- coding: utf-8 -*-

from PySide import QtCore, QtGui


class Ui_Crear_noticia(object):
    def setupUi(self, Window):
        Window.setObjectName("Window")
        Window.resize(444, 576)
        
        self.comboBox = QtGui.QComboBox(Window)
        self.comboBox.setGeometry(QtCore.QRect(170, 30, 141, 27))
        self.comboBox.setObjectName("comboBox")
        
        self.lineEdit = QtGui.QLineEdit(Window)
        self.lineEdit.setGeometry(QtCore.QRect(130, 90, 281, 27))
        self.lineEdit.setObjectName("lineEdit")
        
        self.label = QtGui.QLabel(Window)
        self.label.setGeometry(QtCore.QRect(70, 30, 91, 20))
        self.label.setObjectName("label")
        
        self.label_2 = QtGui.QLabel(Window)
        self.label_2.setGeometry(QtCore.QRect(40, 90, 66, 17))
        self.label_2.setObjectName("label_2")
        
        self.label_3 = QtGui.QLabel(Window)
        self.label_3.setGeometry(QtCore.QRect(30, 150, 66, 17))
        self.label_3.setText("")
        self.label_3.setObjectName("label_3")
        
        self.label_4 = QtGui.QLabel(Window)
        self.label_4.setGeometry(QtCore.QRect(40, 140, 51, 17))
        self.label_4.setObjectName("label_4")
        
        self.label_8 = QtGui.QLabel(Window)
        self.label_8.setGeometry(QtCore.QRect(30, 220, 66, 17))
        self.label_8.setText("")
        self.label_8.setObjectName("label_8")
        
        self.lineEdit_2 = QtGui.QLineEdit(Window)
        self.lineEdit_2.setGeometry(QtCore.QRect(130, 480, 281, 27))
        self.lineEdit_2.setObjectName("lineEdit_2")
        
        self.label_13 = QtGui.QLabel(Window)
        self.label_13.setGeometry(QtCore.QRect(40, 190, 81, 21))
        self.label_13.setObjectName("label_13")
        
        self.Editar = QtGui.QPushButton(Window)
        self.Editar.setGeometry(QtCore.QRect(100, 520, 100, 30))
        self.Editar.setObjectName("Crear")
        
        self.Salir = QtGui.QPushButton(Window)
        self.Salir.setGeometry(QtCore.QRect(240, 520, 100, 30))
        self.Salir.setObjectName("Crear_2")
        
        self.dateEdit = QtGui.QDateEdit(Window)
        self.dateEdit.setGeometry(QtCore.QRect(130, 140, 110, 27))
        self.dateEdit.setObjectName("dateEdit")
        
        self.textEdit = QtGui.QTextEdit(Window)
        self.textEdit.setGeometry(QtCore.QRect(130, 190, 281, 78))
        self.textEdit.setObjectName("textEdit")
        
        self.textEdit_2 = QtGui.QTextEdit(Window)
        self.textEdit_2.setGeometry(QtCore.QRect(130, 300, 281, 111))
        self.textEdit_2.setObjectName("textEdit_2")
        
        self.label_15 = QtGui.QLabel(Window)
        self.label_15.setGeometry(QtCore.QRect(40, 300, 81, 21))
        self.label_15.setObjectName("label_15")
  
        self.label_16 = QtGui.QLabel(Window)
        self.label_16.setGeometry(QtCore.QRect(40, 430, 81, 21))
        self.label_16.setObjectName("label_16")
        
        self.label_17 = QtGui.QLabel(Window)
        self.label_17.setGeometry(QtCore.QRect(40, 480, 81, 21))
        self.label_17.setObjectName("label_17")

        self.radioButton = QtGui.QRadioButton(Window)
        self.radioButton.setGeometry(QtCore.QRect(140, 430, 116, 22))
        self.radioButton.setObjectName("radioButton")
        self.radioButton_2 = QtGui.QRadioButton(Window)
        self.radioButton_2.setGeometry(QtCore.QRect(200, 430, 116, 22))
        self.radioButton_2.setObjectName("radioButton_2")
        
        self.retranslateUi(Window)
        QtCore.QMetaObject.connectSlotsByName(Window)

    def retranslateUi(self, Window):
        Window.setWindowTitle(QtGui.QApplication.translate("Window", "Noticia", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Window", "Categoria", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("Window", "Titulo :", None, QtGui.QApplication.UnicodeUTF8))
        self.label_4.setText(QtGui.QApplication.translate("Window", "Fecha :", None, QtGui.QApplication.UnicodeUTF8))
        self.label_13.setText(QtGui.QApplication.translate("Window", "Resumen :   ", None, QtGui.QApplication.UnicodeUTF8))
        self.label_15.setText(QtGui.QApplication.translate("Window", "Texto:   ", None, QtGui.QApplication.UnicodeUTF8))
        self.label_16.setText(QtGui.QApplication.translate("Window", "Publicidad :", None, QtGui.QApplication.UnicodeUTF8))
        self.label_17.setText(QtGui.QApplication.translate("Window", "Autor :", None, QtGui.QApplication.UnicodeUTF8))
        self.Editar.setText(QtGui.QApplication.translate("Window", "Guardar", None, QtGui.QApplication.UnicodeUTF8))
        self.Salir.setText(QtGui.QApplication.translate("Window", "Salir", None, QtGui.QApplication.UnicodeUTF8))
        self.radioButton.setText(QtGui.QApplication.translate("Sucursal", "Si", None, QtGui.QApplication.UnicodeUTF8))
        self.radioButton_2.setText(QtGui.QApplication.translate("Sucursal", "No", None, QtGui.QApplication.UnicodeUTF8))
        self.dateEdit.setDisplayFormat(QtGui.QApplication.translate("Sucursal", "dd-MM-yyyy", None, QtGui.QApplication.UnicodeUTF8))



