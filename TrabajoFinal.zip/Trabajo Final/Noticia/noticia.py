#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from PySide import QtGui, QtCore
import main_crear_noticia
import main_editar_noticia
import controller_n
from ventana_noticia import Ui_Noticia
import main_categoria
import datetime

class main(QtGui.QDialog):

    def __init__(self):
        super(main, self).__init__()
        self.ui = Ui_Noticia()
        self.ui.setupUi(self)
        self.set_listeners()
        self.cargar_noticias()
        self.show()
        
    def set_listeners(self):
        self.ui.Editar.clicked.connect(self.show_edit)
        self.ui.Eliminar.clicked.connect(self.show_delete)
        self.ui.Crear.clicked.connect(self.show_add)
        self.ui.Salir.clicked.connect(self.cancel)
        self.ui.categoria.clicked.connect(self.get_categoria)
        self.ui.Btn_search.clicked.connect(self.buscar)
        self.ui.checkBox.stateChanged.connect(self.seleccion_check)
        self.ui.checkBox_2.stateChanged.connect(self.seleccion_check)
        self.ui.checkBox_3.stateChanged.connect(self.seleccion_check)
       
    def cancel(self):
        self.reject()
      
    def edit(self):
        self.reject()
        form = main_editar_noticia.main()
        form.exec_()

    def create(self):
        self.reject()
        form2 = main_crear_noticia.main()
        form2.exec_()

    def get_categoria(self):
        form3 = main_categoria.Categoria()
        form3.rejected.connect(self.cargar_noticias)
        form3.exec_()
        
    #rellena la grilla con las noticias
    def cargar_noticias(self, noticia = None):
        
        if noticia is None:
            noticia = controller_n.obtener_noticia()

        self.model = QtGui.QStandardItemModel(len(noticia),8)
        self.model.setHorizontalHeaderItem(0, QtGui.QStandardItem(u"Titulo"))
        self.model.setHorizontalHeaderItem(1, QtGui.QStandardItem(u"Fecha"))
        self.model.setHorizontalHeaderItem(2, QtGui.QStandardItem(u"Resumen"))
        self.model.setHorizontalHeaderItem(3, QtGui.QStandardItem(u"Texto"))
        self.model.setHorizontalHeaderItem(4, QtGui.QStandardItem(u"Publicada"))
        self.model.setHorizontalHeaderItem(5, QtGui.QStandardItem(u"Autor"))
        self.model.setHorizontalHeaderItem(6, QtGui.QStandardItem(u"id_evento"))
        self.model.setHorizontalHeaderItem(7, QtGui.QStandardItem(u"Nombre"))
        
        # busca la noticia por el campo nombre
        completer = QtGui.QCompleter(map(lambda c: c["Nombre"], noticia), self)
        completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        self.ui.Search_box.setCompleter(completer)
            
        r = 0
        for row in noticia:
            index = self.model.index(r, 0, QtCore.QModelIndex());
            self.model.setData(index, row['titulo'])
            index = self.model.index(r, 1, QtCore.QModelIndex());
            self.model.setData(index, row['fecha'])
            index = self.model.index(r, 2, QtCore.QModelIndex());
            self.model.setData(index, row['resumen'])
            index = self.model.index(r, 3, QtCore.QModelIndex());
            self.model.setData(index, row['texto'])
            index = self.model.index(r, 4, QtCore.QModelIndex());
            self.model.setData(index, row['publicada'])
            index = self.model.index(r, 5, QtCore.QModelIndex());
            self.model.setData(index, row['autor'])
            index = self.model.index(r, 6, QtCore.QModelIndex());
            self.model.setData(index, row['id_noticia'])
            index = self.model.index(r, 7, QtCore.QModelIndex());
            self.model.setData(index, row['nombre'])
            r = r+1
                             
        self.ui.tableView.setModel(self.model)
        self.ui.tableView.setColumnWidth(0, 300)
        self.ui.tableView.setColumnWidth(1, 200)
        self.ui.tableView.setColumnWidth(2, 500)
        self.ui.tableView.setColumnWidth(3, 600)
        self.ui.tableView.setColumnWidth(4, 150)
        self.ui.tableView.setColumnWidth(6, 150)
        #oculta campo id de la noticia y nombre de categoria para uso interno
        self.ui.tableView.hideColumn(6)
        self.ui.tableView.hideColumn(7)

    def buscar(self):
        word = self.ui.Search_box.text()
        noti = controller_n.search_noticia(word)
        self.cargar_noticias(noti)
        
    # metodo para obtener recargar grilla con las noticias publicadas, no publicadas y todas
    def seleccion_check(self,noticia = None):
        # se crea un contador para que solo se pueda seleccionar un checkBok
        # si es 0 no hay ninguno seleccionado  
        cont = 0
        if self.ui.checkBox.isChecked() == True:
            cont = cont +1
        if self.ui.checkBox_2.isChecked() == True:
            cont = cont +1
        if self.ui.checkBox_3.isChecked() == True:
            cont = cont +1
         # si cont 1 uno seleccionado y se recarga la grilla segun la opcion seleccionada
        if cont == 1:
            if self.ui.checkBox.isChecked() == True:
                noti = controller_n.obtener_noticia()
                self.cargar_noticias(noti)              
            if self.ui.checkBox_2.isChecked() == True:
               aux = 'S'
               noti = controller_n.obtener_noticia_publicada(aux)
               self.cargar_noticias(noti)  
            if self.ui.checkBox_3.isChecked() == True:
                aux = 'N'
                noti = controller_n.obtener_noticia_publicada(aux)
                self.cargar_noticias(noti)     
        else:
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage(" Debe seleccionar solo una opcion")
        
    # llama al main donde se crea una noticia y la recarga despues de crear la noticia                                
    def show_add(self):
        crear_noticia = main_crear_noticia.main()
        crear_noticia.rejected.connect(self.cargar_noticias)
        crear_noticia.exec_()

    # elimina una noticia
    def show_delete(self):
        model = self.ui.tableView.model()
        index = self.ui.tableView.currentIndex()
        if index.row() == -1:
           self.errorMessageDialog = QtGui.QErrorMessage(self)
           self.errorMessageDialog.showMessage(" Debe seleccionar una fila")
           return False
        else:
            id_noticia = model.index(index.row(), 6, QtCore.QModelIndex()).data()
            self.cargar_noticias()
            msgBox = QtGui.QMessageBox()
            msgBox.setText("El registro fue eliminado.")
            msgBox.setInformativeText("Desea guardar los cambios?")
            msgBox.setStandardButtons(QtGui.QMessageBox.Save | QtGui.QMessageBox.Discard | QtGui.QMessageBox.Cancel)
            msgBox.setDefaultButton(QtGui.QMessageBox.Save)
            ret = msgBox.exec_()
            if ret == QtGui.QMessageBox.Save:
                controller_n.delete(str(id_noticia))
                self.cargar_noticias()
                return True
            else:
                self.ui.errorMessageDialog = QtGui.QErrorMessage(self)
                self.ui.errorMessageDialog.showMessage(" El registro no fue eliminado")
                return False

    # se selecciona una fila y abre la ventana para editar
    def show_edit(self):
        model = self.ui.tableView.model()
        index = self.ui.tableView.currentIndex()
        if index.row() == -1:
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage(" Debe seleccionar una fila")
            return False
        else:
            nombre = model.index(index.row(), 0, QtCore.QModelIndex()).data()
            editar_noticia = main_editar_noticia.main(nombre)
            editar_noticia.rejected.connect(self.cargar_noticias)
            editar_noticia.exec_()
            
    def cancel(self):
        self.reject()
		
def run():
    
    app = QtGui.QApplication(sys.argv)
    ma = main()
    app.exec_()

if __name__ == '__main__':
    run()
