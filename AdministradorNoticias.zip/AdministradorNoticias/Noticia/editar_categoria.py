# -*- coding: utf-8 -*-
from PySide import QtCore, QtGui


class Ui_Editar_categoria(object):
    def setupUi(self, Window):
        Window.setObjectName("Window")
        Window.resize(343, 111)
        self.Editar = QtGui.QPushButton(Window)
        self.Editar.setGeometry(QtCore.QRect(90, 70, 100, 30))
        self.Editar.setObjectName("Crear")
        self.Salir = QtGui.QPushButton(Window)
        self.Salir.setGeometry(QtCore.QRect(230, 70, 100, 30))
        self.Salir.setObjectName("Crear_2")
        self.lineEdit = QtGui.QLineEdit(Window)
        self.lineEdit.setGeometry(QtCore.QRect(90, 30, 241, 27))
        self.lineEdit.setObjectName("lineEdit")
        self.label = QtGui.QLabel(Window)
        self.label.setGeometry(QtCore.QRect(10, 30, 66, 17))
        self.label.setObjectName("label")

        self.retranslateUi(Window)
        QtCore.QMetaObject.connectSlotsByName(Window)

    def retranslateUi(self, Window):
        Window.setWindowTitle(QtGui.QApplication.translate("Window", "Categoria", None, QtGui.QApplication.UnicodeUTF8))
        self.Editar.setText(QtGui.QApplication.translate("Window", "Guardar", None, QtGui.QApplication.UnicodeUTF8))
        self.Salir.setText(QtGui.QApplication.translate("Window", "Salir", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Window", "Nombre :", None, QtGui.QApplication.UnicodeUTF8))



