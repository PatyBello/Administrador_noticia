#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from PySide import QtGui, QtCore
import main_crear_categoria
import main_editar_categoria
import controller
import noticia
from categoria import Ui_Categoria

class Categoria(QtGui.QDialog):

    def __init__(self):
        super(Categoria, self).__init__()
        self.ui = Ui_Categoria()
        self.ui.setupUi(self)
        self.set_listeners()
        self.show_categoria()
        self.show()

    def set_listeners(self):
        self.ui.Editar.clicked.connect(self.show_edit)
        self.ui.Eliminar.clicked.connect(self.show_delete)
        self.ui.Crear.clicked.connect(self.show_add)
        self.ui.Crear_2.clicked.connect(self.cancel)
		
    def edit(self):
        self.reject()
        form = main_editar_categoria.main()
        form.exec_()

    def create(self):
        self.reject()
        form2 = main_crear_categoria.main()
        form2.exec_()
        
    def show_add(self):
        crear_categoria = main_crear_categoria.main()
        crear_categoria.rejected.connect(self.show_categoria)
        crear_categoria.exec_()

    def show_edit(self):
        model = self.ui.tableView.model()
        index = self.ui.tableView.currentIndex()
        if index.row() == -1:
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage(" Debe seleccionar una fila")
            return False
        else:
            nombre = model.index(index.row(), 0, QtCore.QModelIndex()).data()
            editar_categoria = main_editar_categoria.main(nombre)
            editar_categoria.rejected.connect(self.show_categoria)
            editar_categoria.exec_()
        
    # metodo que carga las categorias
    def show_categoria(self, categoria = None):
        if categoria is None :
            categoria = controller.obtener_categoria()

        self.model = QtGui.QStandardItemModel(len(categoria),2)
        self.model.setHorizontalHeaderItem(0, QtGui.QStandardItem(u"Categoria"))
        self.model.setHorizontalHeaderItem(0, QtGui.QStandardItem(u"id_categoria"))

        r = 0
        for row in categoria:
            index = self.model.index(r, 0, QtCore.QModelIndex());
            self.model.setData(index, row['nombre'])
            index = self.model.index(r, 1, QtCore.QModelIndex());
            self.model.setData(index, row['id_categoria'])
            r = r+1     

        self.ui.tableView.setModel(self.model)
        self.ui.tableView.setColumnWidth(0,210)
        self.ui.tableView.setColumnWidth(1,210)
        self.ui.tableView.hideColumn(1)

    # se seleciona una fila y elimina la seleccionada
    def show_delete(self):
        model = self.ui.tableView.model()
        index = self.ui.tableView.currentIndex()
        if index.row() == -1:
           self.errorMessageDialog = QtGui.QErrorMessage(self)
           self.errorMessageDialog.showMessage(" Debe seleccionar una fila")
           return False
        else:
            id_categoria = model.index(index.row(), 1, QtCore.QModelIndex()).data()
            self.show_categoria()
            msgBox = QtGui.QMessageBox()
            msgBox.setText("El registro fue eliminado.")
            msgBox.setInformativeText("Desea guardar los cambios?")
            msgBox.setStandardButtons(QtGui.QMessageBox.Save | QtGui.QMessageBox.Discard | QtGui.QMessageBox.Cancel)
            msgBox.setDefaultButton(QtGui.QMessageBox.Save)
            ret = msgBox.exec_()
            if ret == QtGui.QMessageBox.Save:
                # para poder eliminar una categoria
                #primero se debe eliminar las noticias asociadas a ella
                controller.delete_noticias_asociadas(str(id_categoria))
                controller.delete_categoria(str(id_categoria))
                self.show_categoria()
                return True
            else:
                self.ui.errorMessageDialog = QtGui.QErrorMessage(self)
                self.ui.errorMessageDialog.showMessage(" El registro no fue eliminado")
                return False
       
    def cancel(self):
       self.reject()
    
