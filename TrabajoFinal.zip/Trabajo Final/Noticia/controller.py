#!/usr/bin/python
import sqlite3

def conectar():
    con = sqlite3.connect('base1.db')
    con.row_factory = sqlite3.Row
    return con


def obtener_categoria():
    con = conectar()
    c = con.cursor()
    query = "SELECT nombre , id_categoria FROM categorias ORDER BY nombre ASC "
    resultado = c.execute(query)
    categoria = resultado.fetchall()
    con.close()
    return categoria


def nombre_categoria(nombre):
    con = conectar()
    c = con.cursor()
    query ="""SELECT * FROM categorias WHERE nombre = ? """
    resultado = c.execute(query, [nombre])
    categoria = resultado.fetchall()
    con.close()
    return categoria


def crear_categoria(Nombre):
    exito = False
    con = conectar()
    c = con.cursor()
    values = [None, Nombre]
    query = "INSERT INTO categorias (id_categoria, nombre) VALUES (?,?)"
    try:
        resultado = c.execute(query, values)
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print ("Error:"), e.args[0]
    con.close()
    return exito
		

def id_categoria(nombre):
	con = conectar()
	c = con.cursor()
	query= "SELECT id_categoria FROM categorias WHERE nombre = ?"
	resultado = c.execute(query, [nombre])
	id_categoria = resultado.fetchone()
	con.close
	return id_categoria


def editar_categoria(id_categoria, nombre):
	exito = False
	con = conectar()
	c = con.cursor()
	values = [nombre, id_categoria]
	query = """UPDATE  categorias SET  nombre= ? WHERE id_categoria = ?"""
	try:
		resultado = c.execute(query, values)
		con.commit()
		exito = True
	except sqlite3.Error as e:
		exito = False
		print ("Error:"), e.args[0]
	con.close()
	return exito


def delete_noticias_asociadas(fk_id_categoria): 
    exito = False
    con = conectar()
    c = con.cursor()
    query = "DELETE FROM noticias WHERE fk_id_categoria = ? "
    try:
        resultado = c.execute(query, [fk_id_categoria])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print ("Error:"), e.args[0]
    con.close()
    return exito


def delete_categoria(nombre):
    exito = False
    con = conectar()
    c = con.cursor()
    query = "DELETE FROM categorias  WHERE id_categoria = ? "
    try:
        resultado = c.execute(query, [nombre])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print ("Error:"), e.args[0]
    con.close()
    return exito





