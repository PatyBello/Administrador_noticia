#!/usr/bin/python
import sqlite3

def conectar():
    con = sqlite3.connect('base1.db')
    con.row_factory = sqlite3.Row
    return con

def obtener_noticia():
    con = conectar()
    c = con.cursor()
    query = """SELECT a.titulo, a.fecha, a.resumen, a.texto, a.publicada , a.autor , a.id_noticia  , b.nombre FROM noticias a, categorias b WHERE a.fk_id_categoria = b.id_categoria"""
    resultado = c.execute(query)
    noticia = resultado.fetchall()
    con.close()
    return noticia
  
def obtener_noticia_publicada(aux):
    con = conectar()
    c = con.cursor()
    query ="""SELECT a.titulo, a.fecha, a.texto, a.publicada, a.resumen, a.autor ,b.nombre , a.id_noticia FROM noticias a,
      categorias b WHERE a.fk_id_categoria = b.id_categoria AND a.publicada = ? """
    resultado = c.execute(query, [aux])
    noticias = resultado.fetchall()
    con.close()
    return noticias
  
def crear_noticia(categoria, op, titulo, autor, fecha, resumen, texto):
	exito = False
	con = conectar()
	c = con.cursor()
	values = [None, titulo, fecha, resumen, texto, op, categoria, autor]
	query = "INSERT INTO noticias (id_noticia, titulo ,fecha ,resumen ,texto ,publicada ,fk_id_categoria ,autor) VALUES (?,?,?,?,?,?,?,?)"
	try:
		resultado = c.execute(query, values)
		con.commit()
		exito = True
	except sqlite3.Error as e:
		exito = False
		print ("Error:"), e.args[0]
		con.close()
	return exito

def obtener_categoria():
    con = conectar()
    c = con.cursor()
    query = "SELECT * FROM categorias "
    resultado= c.execute(query)
    categoria = resultado.fetchall()
    con.close()
    return categoria

def delete(id_noticia):
    exito = False
    con = conectar()
    c = con.cursor()
    query = "DELETE FROM noticias WHERE  id_noticia = ?"
    try:
        resultado = c.execute(query, [id_noticia])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print ("Error:"), e.args[0]
    con.close()
    return exito

def search_noticia(word):
    con = conectar()
    c = con.cursor()
    query = """SELECT a.titulo, a.fecha, a.resumen, a.texto, a.publicada , a.autor , a.id_noticia , b.nombre
            FROM noticias a, categorias b WHERE a.fk_id_categoria = b.id_categoria and b.nombre = ?
            AND (a.titulo LIKE '%'||?||'%' OR a.fecha LIKE '%'||?||'%' OR a.resumen LIKE '%'||?||'%' OR a.texto LIKE '%'||?||'%' OR a.publicada LIKE '%'||?||'%' OR a.autor LIKE '%'||?||'%' OR b.nombre LIKE '%'||?||'%')"""

    result = c.execute(query, [word, word, word ,word, word, word,word , word])
    movies = result.fetchall()
    con.close()
    return movies
  
def obtener_noticia_nombre(nombre):
    con = conectar()
    c = con.cursor()
    query ="""SELECT a.titulo, a.fecha, a.texto, a.publicada, a.resumen, a.autor ,b.nombre , a.id_noticia
           FROM noticias a, categorias b WHERE a.fk_id_categoria = b.id_categoria AND a.titulo = ?"""
    resultado = c.execute(query, [nombre])
    noticias = resultado.fetchone()
    con.close()
    return noticias

def editar_noticia(titulo, fecha, texto, resumen, publicada, autor, id_noticia ,fk_id_categoria):
	exito = False
	con = conectar()
	c = con.cursor()
	values = [titulo, fecha, texto, resumen, publicada, autor, fk_id_categoria, id_noticia ]
	query = """UPDATE  noticias SET  titulo = ?, fecha = ?, texto = ?, resumen = ? , publicada = ?, autor = ?, fk_id_categoria = ? WHERE id_noticia = ?"""
	try:
		resultado = c.execute(query, values)
		con.commit()
		exito = True
	except sqlite3.Error as e:
		exito = False
		print ("Error:"), e.args[0]
	con.close()
	return exito

