# -*- coding: utf-8 -*-


from PySide import QtCore, QtGui


class Ui_Categoria(object):
    def setupUi(self, categoria):
        categoria.setObjectName("categoria")
        categoria.resize(394, 387)
        self.Eliminar = QtGui.QPushButton(categoria)
        self.Eliminar.setGeometry(QtCore.QRect(270, 100, 100, 30))
        self.Eliminar.setObjectName("Eliminar")
        self.Editar = QtGui.QPushButton(categoria)
        self.Editar.setGeometry(QtCore.QRect(270, 60, 100, 30))
        self.Editar.setObjectName("Editar")
        self.Crear = QtGui.QPushButton(categoria)
        self.Crear.setGeometry(QtCore.QRect(270, 20, 100, 30))
        self.Crear.setObjectName("Crear")
        self.tableView = QtGui.QTableView(categoria)
        self.tableView.setGeometry(QtCore.QRect(20, 20, 221, 341))
        self.tableView.setObjectName("tableView")
        self.Crear_2 = QtGui.QPushButton(categoria)
        self.Crear_2.setGeometry(QtCore.QRect(270, 140, 100, 30))
        self.Crear_2.setObjectName("Crear_2")

        self.retranslateUi(categoria)
        QtCore.QMetaObject.connectSlotsByName(categoria)

    def retranslateUi(self, categoria):
        categoria.setWindowTitle(QtGui.QApplication.translate("categoria", "Categorias", None, QtGui.QApplication.UnicodeUTF8))
        self.Eliminar.setText(QtGui.QApplication.translate("categoria", "Eliminar", None, QtGui.QApplication.UnicodeUTF8))
        self.Editar.setText(QtGui.QApplication.translate("categoria", "Editar", None, QtGui.QApplication.UnicodeUTF8))
        self.Crear.setText(QtGui.QApplication.translate("categoria", "Crear", None, QtGui.QApplication.UnicodeUTF8))
        self.Crear_2.setText(QtGui.QApplication.translate("categoria", "Salir", None, QtGui.QApplication.UnicodeUTF8))


