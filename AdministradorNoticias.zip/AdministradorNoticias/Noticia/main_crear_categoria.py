#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import controller
from PySide import QtGui, QtCore
from Crear_categoria import Ui_Crear_categoria

class main(QtGui.QDialog):

    def __init__(self):
        super(main, self).__init__()
        self.ui = Ui_Crear_categoria()
        self.ui.setupUi(self)
        self.set_listeners()
        self.show()

    def set_listeners(self):
        self.ui.Crear.clicked.connect(self.agregar)
        self.ui.Crear_2.clicked.connect(self.cancel)

    # metodo para crear una categoria
    def agregar(self):
        nombre = self.ui.lineEdit.text()
        # si hay un nombre ingresado 
        if nombre:
            # existencia la consulta busca el nombre si entrega valores
            # el nombre existe si no lo agrega
            nuevo = controller.nombre_categoria(str(nombre))
            if nuevo:
                self.errorMessageDialog = QtGui.QErrorMessage(self)
                self.errorMessageDialog.showMessage("la categoria ya existe")    
            else:
                resultado = controller.crear_categoria(nombre)
                if resultado:
                    self.errorMessageDialog = QtGui.QErrorMessage(self)
                    self.errorMessageDialog.showMessage("La categoria se a creado correctamente")
                else:
                    self.errorMessageDialog = QtGui.QErrorMessage(self)
                    self.errorMessageDialog.showMessage("A sucedido un problema no se a podido crear el registro")     
        else:
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage("Debe ingresar un nombre")

    def cancel(self):
        self.reject()  
