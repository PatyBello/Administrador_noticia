#!/usr/bin/python
# -*- coding: utf-8 -*-

from PySide import QtCore, QtGui


class Ui_Noticia(object):
    def setupUi(self,Window):
        Window.setObjectName("Window")
        Window.resize(720, 460)

        
        self.Eliminar = QtGui.QPushButton(Window)
        self.Eliminar.setGeometry(QtCore.QRect(510, 420, 100, 30))
        self.Eliminar.setObjectName("Eliminar")
        
        self.Salir = QtGui.QPushButton(Window)
        self.Salir.setGeometry(QtCore.QRect(610, 420, 100, 30))
        self.Salir.setObjectName("Salir")
        
        self.Editar = QtGui.QPushButton(Window)
        self.Editar.setGeometry(QtCore.QRect(410, 420, 100, 30))
        self.Editar.setObjectName("Editar")

        
        self.Crear = QtGui.QPushButton(Window)
        self.Crear.setGeometry(QtCore.QRect(310, 420, 100, 30))
        self.Crear.setObjectName("Crear")
        
        
        self.categoria= QtGui.QPushButton(Window)
        self.categoria.setGeometry(QtCore.QRect(10, 420, 98, 27))
        self.categoria.setObjectName("Categoria")

        self.Btn_search = QtGui.QPushButton(Window)
        self.Btn_search.setGeometry(QtCore.QRect(300, 30, 100, 30))
        self.Btn_search.setObjectName("Btn_search")
        
        self.Search_box = QtGui.QLineEdit(Window)
        self.Search_box.setGeometry(QtCore.QRect(10, 30, 290, 30))
        self.Search_box.setStyleSheet("")
        self.Search_box.setObjectName("Search_box")
        
        self.tableView = QtGui.QTableView(Window)
        self.tableView.setGeometry(QtCore.QRect(10, 80, 700, 320))
        self.tableView.setObjectName("tableView")
        
        self.label = QtGui.QLabel(Window)
        self.label.setGeometry(QtCore.QRect(510, 30, 91, 20))
        self.label.setObjectName("label")
        

        self.groupBox = QtGui.QGroupBox(Window)
        self.groupBox.setGeometry(QtCore.QRect(459,10,241,60))
        self.groupBox.setObjectName("groupBox")
        
        self.checkBox = QtGui.QCheckBox(self.groupBox)
        self.checkBox.setGeometry(QtCore.QRect(0, 20, 71, 22))
        self.checkBox.setObjectName("checkBox")
        
        self.checkBox_2 = QtGui.QCheckBox(self.groupBox)
        self.checkBox_2.setGeometry(QtCore.QRect(70, 20, 97, 22))
        self.checkBox_2.setObjectName("checkBox_2")
        
        self.checkBox_3 = QtGui.QCheckBox(self.groupBox)
        self.checkBox_3.setGeometry(QtCore.QRect(140, 20, 97, 22))
        self.checkBox_3.setObjectName("checkBox_3")
        self.groupBox.setCheckable(True)

        self.retranslateUi(Window)
        QtCore.QMetaObject.connectSlotsByName(Window)

    def retranslateUi(self, Window):
        Window.setWindowTitle(QtGui.QApplication.translate("Window", "Noticias", None, QtGui.QApplication.UnicodeUTF8))
        self.Eliminar.setText(QtGui.QApplication.translate("Window", "Eliminar", None, QtGui.QApplication.UnicodeUTF8))
        self.Salir.setText(QtGui.QApplication.translate("Window", "Salir", None, QtGui.QApplication.UnicodeUTF8))
        self.Editar.setText(QtGui.QApplication.translate("Window", "Editar", None, QtGui.QApplication.UnicodeUTF8))
        self.Crear.setText(QtGui.QApplication.translate("Window", "Crear", None, QtGui.QApplication.UnicodeUTF8))
        self.Btn_search.setText(QtGui.QApplication.translate("Window", "Buscar", None, QtGui.QApplication.UnicodeUTF8))
        self.Search_box.setText(QtGui.QApplication.translate("Window", "Buscar noticia", None, QtGui.QApplication.UnicodeUTF8))
        self.Search_box.setPlaceholderText(QtGui.QApplication.translate("Window", "Buscar titulo aquí", None, QtGui.QApplication.UnicodeUTF8))
        self.categoria.setText(QtGui.QApplication.translate("Window", "Categoria", None, QtGui.QApplication.UnicodeUTF8))
        self.checkBox.setText(QtGui.QApplication.translate("Window", "Todas", None, QtGui.QApplication.UnicodeUTF8))
        self.checkBox_2.setText(QtGui.QApplication.translate("Window", "Si", None, QtGui.QApplication.UnicodeUTF8))
        self.checkBox_3.setText(QtGui.QApplication.translate("Window", "No", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setTitle(QtGui.QApplication.translate("Window", "Publicada", None, QtGui.QApplication.UnicodeUTF8))
