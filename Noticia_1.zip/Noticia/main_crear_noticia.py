#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import controller_n
from PySide import QtGui, QtCore
from Crear_noticia import Ui_Crear_noticia


class main(QtGui.QDialog):

    def __init__(self):
        super(main, self).__init__()
        self.ui = Ui_Crear_noticia()
        self.ui.setupUi(self)
        self.set_listeners()
        self.cargar_categoria()
        self.show()

    def cargar_categoria(self ):
        categoria = controller_n.obtener_categoria()
        for cate in categoria:
            self.ui.comboBox.addItem(cate["nombre"], cate["id_categoria"])
        
    def radio_boto(self, aux = None , categoria = None):
        cont = 0
        if self.ui.radioButton.isChecked() == True:
            cont = cont +1
  
        if self.ui.radioButton_2.isChecked() == True:
            cont = cont +1
        
        if cont == 1:
            
            if self.ui.radioButton.isChecked() == True:
                aux = 'S'
                categoria =self.ui.comboBox.itemData(self.ui.comboBox.currentIndex())
                
            if self.ui.radioButton_2.isChecked() == True:
                aux = 'N'
                categoria =self.ui.comboBox.itemData(self.ui.comboBox.currentIndex())
           
            return aux , categoria
        
        else:
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage("No a seleccionado una opcion para el campo publicada ")
       
    
    def agregar(self , crear_noticia = None):
         
         titulo = self.ui.lineEdit.text()
         autor = self.ui.lineEdit_2.text()
         year = self.ui.dateEdit.date().year()
         month = self.ui.dateEdit.date().month()
         day = self.ui.dateEdit.date().day()
         resumen = self.ui.textEdit.toPlainText()
         texto = self.ui.textEdit_2.toPlainText()
         
         aux = self.radio_boto()
         
         fecha = day , month , year
         fecha_in =str('{:0>2}'.format(fecha[0]))+ "-" + str('{:0>2}'.format(fecha[1])) + "-" + str(fecha[2])

         if aux:
             if titulo:
                 if autor:
                     if texto:
                         if resumen:
                             crear_noticia = controller_n.crear_noticia(aux[1], aux[0], titulo, autor, fecha_in, resumen, texto)
                             self.errorMessageDialog = QtGui.QErrorMessage(self)
                             self.errorMessageDialog.showMessage("La noticia se a creado correctamente")
                         else:
                              self.errorMessageDialog = QtGui.QErrorMessage(self)
                              self.errorMessageDialog.showMessage("El campo resumen es obligatorio ")
                     else:
                         self.errorMessageDialog = QtGui.QErrorMessage(self)
                         self.errorMessageDialog.showMessage("El campo texto es obligatorio ")
                 else:
                     self.errorMessageDialog = QtGui.QErrorMessage(self)
                     self.errorMessageDialog.showMessage("El campo autor es obligatorio ")
             else:
                 self.errorMessageDialog = QtGui.QErrorMessage(self)
                 self.errorMessageDialog.showMessage("El campo titulo es obligatorio ")
         else:
             self.errorMessageDialog = QtGui.QErrorMessage(self)
             self.errorMessageDialog.showMessage("No a Seleccionado publicada")
                         
    def set_listeners(self):
        self.ui.Editar.clicked.connect(self.agregar)
        self.ui.Salir.clicked.connect(self.cancel)
        

    def cancel(self):
        self.reject()  

